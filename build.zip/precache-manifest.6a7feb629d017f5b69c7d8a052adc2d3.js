self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "28d3f199bc4c1802e0d8887cf4d4c673",
    "url": "/SmartFridge/index.html"
  },
  {
    "revision": "38c3ae320bab82f12832",
    "url": "/SmartFridge/static/css/main.12246a7f.chunk.css"
  },
  {
    "revision": "2f5b6cee23d141ae1251",
    "url": "/SmartFridge/static/js/2.9f1d077b.chunk.js"
  },
  {
    "revision": "82829cca1766fd3a7030",
    "url": "/SmartFridge/static/js/3.2308379b.chunk.js"
  },
  {
    "revision": "38c3ae320bab82f12832",
    "url": "/SmartFridge/static/js/main.03e3e391.chunk.js"
  },
  {
    "revision": "809daf34a25c48a327b3",
    "url": "/SmartFridge/static/js/runtime~main.8c56edbf.js"
  }
]);